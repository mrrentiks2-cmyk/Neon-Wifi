package app.neonwifi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;

import java.lang.ref.WeakReference;

/**
 * "Boost": holds Wi-Fi locks so the radio does not drop into power-save between packets
 * (lower and steadier latency). Runs as a foreground service so it survives leaving the app.
 */
public class BoostService extends Service {
    static final String CH = "boost", ACT_STOP = "app.neonwifi.STOP_BOOST";
    static final int NID = 3;
    static volatile boolean running;
    static WeakReference<MainActivity> activity = new WeakReference<>(null);
    private WifiManager.WifiLock hp, ll;

    static void start(Context c) { try { c.startForegroundService(new Intent(c, BoostService.class)); } catch (Exception ignored) { } }

    static void stop(Context c) { c.stopService(new Intent(c, BoostService.class)); }

    @Override
    @SuppressWarnings("deprecation")
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        Notification n = notification();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NID, n);
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            if (hp == null) {
                hp = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "neonwifi:boost");
                hp.setReferenceCounted(false);
                hp.acquire();
            }
            if (ll == null && Build.VERSION.SDK_INT >= 29) {
                ll = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "neonwifi:lowlatency");
                ll.setReferenceCounted(false);
                ll.acquire();
            }
        } catch (Exception ignored) { }
        running = true;
        MainActivity a = activity.get();
        if (a != null) a.emitBoost();
        return START_STICKY;
    }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Ускорение Wi‑Fi", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2, new Intent(this, BoostService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Ускорение Wi‑Fi включено")
                .setContentText("Wi‑Fi без энергосбережения: пинг ниже и ровнее")
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Выключить", stop).build())
                .build();
    }

    @Override
    public void onDestroy() {
        try { if (hp != null && hp.isHeld()) hp.release(); } catch (Exception ignored) { }
        try { if (ll != null && ll.isHeld()) ll.release(); } catch (Exception ignored) { }
        hp = null; ll = null;
        running = false;
        MainActivity a = activity.get();
        if (a != null) a.emitBoost();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
