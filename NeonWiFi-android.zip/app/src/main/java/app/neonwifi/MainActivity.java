package app.neonwifi;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.RouteInfo;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_PERM = 11, REQ_ADD = 12, REQ_NOTIF = 13;

    WebView web;
    WifiManager wm;
    ConnectivityManager cm;
    NetTest net;
    SharedPreferences prefs;
    final Handler ui = new Handler(Looper.getMainLooper());
    volatile Network wifiNet;
    volatile WifiInfo cbInfo;
    volatile int insetTop;
    boolean live, receiversOn;
    ConnectivityManager.NetworkCallback cb;

    final Runnable liveTick = new Runnable() {
        @Override
        @SuppressWarnings("deprecation")
        public void run() {
            if (!live) return;
            try {
                WifiInfo i = wm.getConnectionInfo();
                if (i != null && i.getRssi() > -127 && wifiNet != null)
                    emit(new JSONObject().put("type", "rssi").put("rssi", i.getRssi()).put("link", i.getLinkSpeed()));
            } catch (Exception ignored) { }
            ui.postDelayed(this, 1000);
        }
    };

    final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(a)) emitScan();
            else if (WifiManager.WIFI_STATE_CHANGED_ACTION.equals(a)) {
                try { emit(new JSONObject().put("type", "wifi").put("on", wm.isWifiEnabled())); } catch (Exception ignored) { }
            } else if (LocationManager.PROVIDERS_CHANGED_ACTION.equals(a)) {
                try { emit(new JSONObject().put("type", "loc").put("on", locOn())); } catch (Exception ignored) { }
            }
        }
    };

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("app", MODE_PRIVATE);
        wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        net = new NetTest(this::emit);
        BoostService.activity = new java.lang.ref.WeakReference<>(this);

        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(0xFF07070E);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.getDecorView().setOnApplyWindowInsetsListener((v, ins) -> { insetTop = ins.getSystemWindowInsetTop(); return v.onApplyWindowInsets(ins); });

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07070E);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) { return loader.shouldInterceptRequest(req.getUrl()); }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (HOST.equals(req.getUrl().getHost())) return false;
                openUrl(req.getUrl().toString());
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "W");
        watchWifi();
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    /* ======================= events ======================= */
    void emit(JSONObject e) {
        final String js = "window.__wEvent && window.__wEvent(" + JSONObject.quote(e.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void emitBoost() { try { emit(new JSONObject().put("type", "boost").put("on", BoostService.running)); } catch (Exception ignored) { } }

    void emitConn() { try { emit(new JSONObject().put("type", "conn").put("conn", conn())); } catch (Exception ignored) { } }

    void emitScan() {
        try { emit(new JSONObject().put("type", "scan").put("list", scanList())); } catch (Exception ignored) { }
    }

    private void watchWifi() {
        NetworkRequest req = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
        cb = Build.VERSION.SDK_INT >= 31 ? new ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities nc) { onCaps(n, nc); }
            @Override public void onLinkPropertiesChanged(Network n, LinkProperties lp) { wifiNet = n; emitConn(); }
            @Override public void onLost(Network n) { if (n.equals(wifiNet)) { wifiNet = null; cbInfo = null; emitConn(); } }
        } : new ConnectivityManager.NetworkCallback() {
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities nc) { onCaps(n, nc); }
            @Override public void onLinkPropertiesChanged(Network n, LinkProperties lp) { wifiNet = n; emitConn(); }
            @Override public void onLost(Network n) { if (n.equals(wifiNet)) { wifiNet = null; cbInfo = null; emitConn(); } }
        };
        try { cm.registerNetworkCallback(req, cb); } catch (Exception ignored) { }
    }

    private void onCaps(Network n, NetworkCapabilities nc) {
        boolean changed = !n.equals(wifiNet);
        wifiNet = n;
        if (Build.VERSION.SDK_INT >= 29 && nc.getTransportInfo() instanceof WifiInfo) {
            WifiInfo old = cbInfo, i = (WifiInfo) nc.getTransportInfo();
            cbInfo = i;
            if (old == null || !String.valueOf(old.getBSSID()).equals(String.valueOf(i.getBSSID())) || !String.valueOf(old.getSSID()).equals(String.valueOf(i.getSSID()))) changed = true;
        }
        if (changed) emitConn();
    }

    /* ======================= data ======================= */
    boolean fine() { return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }

    boolean locOn() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            return Build.VERSION.SDK_INT >= 28 ? lm.isLocationEnabled() : lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) { return true; }
    }

    static String cleanSsid(String s) {
        if (s == null || "<unknown ssid>".equals(s) || "0x".equals(s)) return "";
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) return s.substring(1, s.length() - 1);
        return s;
    }

    @SuppressWarnings("deprecation")
    JSONObject conn() {
        JSONObject o = new JSONObject();
        try {
            Network n = wifiNet;
            WifiInfo i = wm.getConnectionInfo();
            WifiInfo ci = cbInfo;
            boolean connected = n != null || (i != null && i.getNetworkId() != -1 && i.getRssi() > -127);
            o.put("connected", connected && wm.isWifiEnabled());
            if (!connected || i == null) return o;
            String ssid = cleanSsid(ci != null ? ci.getSSID() : i.getSSID());
            if (ssid.isEmpty()) ssid = cleanSsid(i.getSSID());
            String bssid = ci != null && ci.getBSSID() != null ? ci.getBSSID() : i.getBSSID();
            if ("02:00:00:00:00:00".equals(bssid)) bssid = null;
            o.put("ssid", ssid);
            if (bssid != null) o.put("bssid", bssid.toLowerCase());
            o.put("rssi", i.getRssi());
            o.put("freq", i.getFrequency());
            o.put("link", i.getLinkSpeed());
            if (Build.VERSION.SDK_INT >= 29) { o.put("tx", i.getTxLinkSpeedMbps()); o.put("rx", i.getRxLinkSpeedMbps()); }
            if (Build.VERSION.SDK_INT >= 30) { o.put("std", i.getWifiStandard()); o.put("maxTx", i.getMaxSupportedTxLinkSpeedMbps()); }
            LinkProperties lp = n != null ? cm.getLinkProperties(n) : null;
            if (lp != null) {
                for (LinkAddress la : lp.getLinkAddresses()) if (la.getAddress() instanceof Inet4Address) { o.put("ip", la.getAddress().getHostAddress()); break; }
                for (RouteInfo r : lp.getRoutes()) {
                    InetAddress g = r.getGateway();
                    if (r.isDefaultRoute() && g instanceof Inet4Address && !g.isAnyLocalAddress()) { o.put("gw", g.getHostAddress()); break; }
                }
                JSONArray dns = new JSONArray();
                for (InetAddress d : lp.getDnsServers()) dns.put(d.getHostAddress());
                o.put("dns", dns);
            }
            if (!o.has("gw")) {
                int g = wm.getDhcpInfo() != null ? wm.getDhcpInfo().gateway : 0;
                if (g != 0) o.put("gw", (g & 0xff) + "." + (g >> 8 & 0xff) + "." + (g >> 16 & 0xff) + "." + (g >> 24 & 0xff));
            }
        } catch (Exception ignored) { }
        return o;
    }

    @SuppressWarnings("deprecation")
    JSONArray scanList() {
        JSONArray a = new JSONArray();
        if (!fine()) return a;
        try {
            List<ScanResult> list = wm.getScanResults();
            long now = SystemClock.elapsedRealtime();
            for (ScanResult r : list) {
                long ageMs = now - r.timestamp / 1000;
                if (ageMs > 5 * 60_000) continue;
                JSONObject o = new JSONObject();
                o.put("ssid", r.SSID == null ? "" : r.SSID);
                o.put("bssid", r.BSSID == null ? "" : r.BSSID.toLowerCase());
                o.put("rssi", r.level);
                o.put("freq", r.frequency);
                o.put("caps", r.capabilities);
                o.put("width", r.channelWidth);
                if (Build.VERSION.SDK_INT >= 30) o.put("std", r.getWifiStandard());
                o.put("age", ageMs);
                a.put(o);
            }
        } catch (Exception ignored) { }
        return a;
    }

    /* ======================= actions ======================= */
    void openUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { ui.post(() -> Toast.makeText(this, "Нет приложения, чтобы открыть ссылку", Toast.LENGTH_SHORT).show()); }
    }

    void openPanel() {
        try {
            if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_WIFI));
            else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) { } }
    }

    /** hand a network to Android: save-and-connect dialog (11+), Wi-Fi panel (10), direct connect (≤9) */
    @SuppressWarnings("deprecation")
    String connect(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String ssid = o.optString("ssid"), sec = o.optString("sec"), pass = o.optString("pass");
            if (Build.VERSION.SDK_INT >= 30) {
                if ("WEP".equals(sec)) { ui.post(this::openPanel); return "panel"; }
                WifiNetworkSuggestion.Builder sb = new WifiNetworkSuggestion.Builder().setSsid(ssid);
                if ("WPA3".equals(sec)) sb.setWpa3Passphrase(pass);
                else if ("OWE".equals(sec)) sb.setIsEnhancedOpen(true);
                else if (!pass.isEmpty()) sb.setWpa2Passphrase(pass);
                ArrayList<Parcelable> list = new ArrayList<>();
                list.add(sb.build());
                Intent i = new Intent(Settings.ACTION_WIFI_ADD_NETWORKS);
                i.putParcelableArrayListExtra(Settings.EXTRA_WIFI_NETWORK_LIST, list);
                ui.post(() -> { try { startActivityForResult(i, REQ_ADD); } catch (Exception e) { openPanel(); } });
                return "add";
            }
            if (Build.VERSION.SDK_INT == 29) { ui.post(this::openPanel); return "panel"; }
            WifiConfiguration c = new WifiConfiguration();
            c.SSID = "\"" + ssid + "\"";
            if (pass.isEmpty()) c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            else if ("WEP".equals(sec)) { c.wepKeys[0] = "\"" + pass + "\""; c.wepTxKeyIndex = 0; c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE); c.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40); }
            else c.preSharedKey = "\"" + pass + "\"";
            int id = wm.addNetwork(c);
            if (id == -1) {
                for (WifiConfiguration x : wm.getConfiguredNetworks()) if (c.SSID.equals(x.SSID)) { id = x.networkId; break; }
            }
            if (id == -1) { ui.post(this::openPanel); return "panel"; }
            wm.disconnect();
            wm.enableNetwork(id, true);
            wm.reconnect();
            return "legacy";
        } catch (Exception e) { return "error"; }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_ADD) return;
        String r = "cancel";
        if (res == RESULT_OK) {
            r = "ok";
            int[] codes = data != null ? data.getIntArrayExtra(Settings.EXTRA_WIFI_NETWORK_RESULT_LIST) : null;
            if (codes != null && codes.length > 0) {
                if (codes[0] == Settings.ADD_WIFI_RESULT_ALREADY_EXISTS) r = "exists";
                else if (codes[0] == Settings.ADD_WIFI_RESULT_ADD_OR_UPDATE_FAILED) r = "fail";
            }
        }
        try { emit(new JSONObject().put("type", "added").put("result", r)); } catch (Exception ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERM) {
            try { emit(new JSONObject().put("type", "perm").put("granted", fine())); } catch (Exception ignored) { }
            emitConn();
            if (fine()) emitScan();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!receiversOn) {
            IntentFilter f = new IntentFilter();
            f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
            f.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
            registerReceiver(rx, f);
            receiversOn = true;
        }
        if (live) { ui.removeCallbacks(liveTick); ui.post(liveTick); }
        try { emit(new JSONObject().put("type", "resume")); } catch (Exception ignored) { }
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(liveTick);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (receiversOn) { try { unregisterReceiver(rx); } catch (Exception ignored) { } receiversOn = false; }
        try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        net.speedStop();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__wBack ? window.__wBack() : false", v -> { if (!"true".equals(v)) moveTaskToBack(true); });
    }

    final class Bridge {
        @JavascriptInterface
        public String insets() {
            int top = insetTop;
            if (top == 0) { int id = getResources().getIdentifier("status_bar_height", "dimen", "android"); if (id > 0) top = getResources().getDimensionPixelSize(id); }
            return "{\"top\":" + Math.round(top / getResources().getDisplayMetrics().density) + "}";
        }

        @JavascriptInterface
        public String state() {
            JSONObject o = new JSONObject();
            try {
                o.put("wifiOn", wm.isWifiEnabled());
                o.put("locOn", locOn());
                o.put("perm", perm());
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("conn", conn());
            } catch (Exception ignored) { }
            return o.toString();
        }

        String perm() {
            if (fine()) return "granted";
            boolean asked = prefs.getBoolean("askedPerm", false);
            if (!asked || shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) return "ask";
            return "denied";
        }

        @JavascriptInterface public String results() { return scanList().toString(); }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public String scan() {
            if (!fine()) return "error";
            try { return wm.startScan() ? "ok" : "throttled"; } catch (SecurityException e) { return "error"; }
        }

        @JavascriptInterface
        public void live(boolean on) {
            ui.post(() -> { live = on; ui.removeCallbacks(liveTick); if (on) ui.post(liveTick); });
        }

        @JavascriptInterface public void ping(String id, String host, int count) { net.ping(id, host, count); }
        @JavascriptInterface public void speedStart() { net.speed(); }
        @JavascriptInterface public void speedStop() { net.speedStop(); }

        @JavascriptInterface
        public void boost(boolean on) {
            ui.post(() -> {
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !prefs.getBoolean("askedNotif", false)) {
                        prefs.edit().putBoolean("askedNotif", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    }
                    BoostService.start(MainActivity.this);
                } else BoostService.stop(MainActivity.this);
            });
        }

        @JavascriptInterface public boolean boostOn() { return BoostService.running; }
        @JavascriptInterface public void openPanel() { ui.post(MainActivity.this::openPanel); }
        @JavascriptInterface public void openWifiSettings() { ui.post(() -> { try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) { } }); }
        @JavascriptInterface public void openLocSettings() { ui.post(() -> { try { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); } catch (Exception ignored) { } }); }

        @JavascriptInterface
        public void askPerm() {
            ui.post(() -> {
                if (prefs.getBoolean("askedPerm", false) && !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) && !fine()) {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
                    return;
                }
                prefs.edit().putBoolean("askedPerm", true).apply();
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM);
            });
        }

        @JavascriptInterface public String connect(String json) { return MainActivity.this.connect(json); }
        @JavascriptInterface public void openUrl(String u) { ui.post(() -> MainActivity.this.openUrl(u)); }

        @JavascriptInterface
        public void share(String text) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Поделиться")); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            ui.post(() -> { ClipboardManager c = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); if (c != null) c.setPrimaryClip(ClipData.newPlainText("Neon Wi-Fi", text)); });
        }

        @JavascriptInterface public void toast(String t) { ui.post(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_SHORT).show()); }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try { Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE)); } catch (Exception ignored) { }
        }

        @JavascriptInterface public String version() { return BuildConfig.VERSION_NAME; }
    }
}
